package com.bhushan.mongodbcrud.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.bhushan.mongodbcrud.entity.Course;
import com.bhushan.mongodbcrud.entity.Teacher;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;
@Service
public class TeacherService {

	@Autowired
	private MongoTemplate mongoTemplate;

	public List<Teacher> getAllTeachers() {
		return mongoTemplate.findAll(Teacher.class);
	}

	public Teacher getTeacherById(String id) {
		return mongoTemplate.findById(id, Teacher.class);
	}

	public Teacher addTeacher(Teacher teacher) {
		return mongoTemplate.save(teacher);
	}

	public boolean updateTeacher(String id, Teacher teacher) {
		Query query = new Query(Criteria.where("id").is(id));
		Update update = new Update().set("name", teacher.getName()).set("courses", teacher.getCourses());

		Teacher updatedTeacher = mongoTemplate.findAndModify(query, update, Teacher.class);
		return updatedTeacher != null;
	}

	public void deleteTeacher(String id) {
		mongoTemplate.remove(mongoTemplate.findById(id, Teacher.class));
	}

	public List<Course> getCoursesByTeacherId(String id) {
		Teacher teacher = mongoTemplate.findById(id, Teacher.class);
		return teacher != null ? teacher.getCourses() : null;
	}

	
	public List<Teacher> findTeachersByCourseName(String courseName) {
	    Aggregation aggregation = Aggregation.newAggregation(
	        // Stage 1: Match courses by name
	        Aggregation.lookup("courses", "courseIds", "_id", "matchedCourses"),
	        Aggregation.unwind("matchedCourses"),
	        Aggregation.match(Criteria.where("matchedCourses.name").is(courseName)),
	        
	        // Stage 2: Group back to teachers
	        Aggregation.group("_id")
	            .first("name").as("name")
	            .first("courseIds").as("courseIds"),
	        
	        // Stage 3: Reconstruct the Teacher object
	        Aggregation.project()
	            .and("_id").as("id")
	            .and("name").as("name")
	            .and("courseIds").as("courseIds")
	    );

	    AggregationResults<Teacher> results = mongoTemplate.aggregate(aggregation, "teachers", Teacher.class);
	    return results.getMappedResults();
	}
//	public List<Teacher> findTeachersByCourseName(String courseName) {
//		Aggregation aggregation = Aggregation.newAggregation(lookup("courses", "courses.$id", "_id", "courseDetails"),
//				unwind("courseDetails"), match(Criteria.where("courseDetails.name").is(courseName)),
//				project("id", "name", "courses"));
//
//		AggregationResults<Teacher> results = mongoTemplate.aggregate(aggregation, "teacher", Teacher.class);
//		return results.getMappedResults();
//	}
//    public List<Teacher> findTeachersByCourseName(String courseName) {
//        // Step 1: Find courses by name
//        Query courseQuery = new Query(Criteria.where("name").is(courseName));
//        List<Course> courses = mongoTemplate.find(courseQuery, Course.class);
//
//        if (courses.isEmpty()) {
//            return List.of();
//        }
//
//        // Step 2: Extract course IDs
//        List<String> courseIds = courses.stream()
//                .map(course -> course.getId().toString())
//                .collect(Collectors.toList());
//
//        // Step 3: Find teachers by course IDs
//        Query teacherQuery = new Query(Criteria.where("courses.$id").in(courseIds));
//        return mongoTemplate.find(teacherQuery, Teacher.class);
//    }
}