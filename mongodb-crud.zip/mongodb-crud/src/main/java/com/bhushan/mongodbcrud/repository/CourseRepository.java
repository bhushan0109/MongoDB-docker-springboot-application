package com.bhushan.mongodbcrud.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.bhushan.mongodbcrud.entity.Course;

public interface CourseRepository extends MongoRepository<Course, String> {
}
//	@Aggregation(pipeline = {
//	        "{ '$match': { 'name': ?0 } }",
//	        "{ '$lookup': { 'from': 'teachers', 'localField': 'teacherId', 'foreignField': '_id', 'as': 'teacher' } }",
//	        "{ '$unwind': '$teacher' }",
//	        "{ '$project': { 'teacherName': '$teacher.name' } }"
//	    })
//	    List<String> findTeacherNameByCourseName(String courseName);
//}

//The pipeline stages are:
//$match to filter the courses by the given name.
//$lookup to join the teachers collection using the teacherId.
//$unwind to deconstruct the joined array.
//$project to select only the teacher's name.