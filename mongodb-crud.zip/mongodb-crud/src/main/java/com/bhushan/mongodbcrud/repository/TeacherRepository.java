package com.bhushan.mongodbcrud.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.bhushan.mongodbcrud.entity.Teacher;

public interface TeacherRepository extends MongoRepository<Teacher, String> {

		@Aggregation(pipeline = {
				"{ '$lookup': { 'from': 'courses', 'localField': 'courseIds', 'foreignField': '_id', 'as': 'courses' } }",
				"{ '$unwind': '$courses' }", "{ '$match': { 'courses.name': ?0 } }",
				"{ '$group': { '_id': '$_id', 'name': { '$first': '$name' }, 'courseIds': { '$first': '$courseIds' } } }" })
		List<Teacher> findTeachersByCourseName(String courseName);
	
}
/*
 * $lookup: This stage performs a left outer join to the courses collection,
 * matching the courseIds field in the teachers collection with the _id field in
 * the courses collection. The result is stored in a new array field called
 * courses.
 * 
 * $unwind: This stage deconstructs the courses array field, creating a separate
 * document for each element in the array.
 * 
 * $match: This stage filters the documents to include only those where the
 * courses.name field matches the specified course name.
 * 
 * $group: This stage groups the documents by the teacher’s _id field and
 * reconstructs the Teacher document fields (name and courseIds).
 */