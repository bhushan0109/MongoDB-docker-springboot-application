package com.bhushan.mongodbcrud.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bhushan.mongodbcrud.entity.ParentDetails;
import com.bhushan.mongodbcrud.entity.Student;
import com.bhushan.mongodbcrud.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping
	public List<Student> getAllStudents() {
		return studentService.getAllStudents();
	}

	@GetMapping("/{id}")
	public Student getStudentById(@PathVariable String id) {
		return studentService.getStudentById(id);
	}

	@PostMapping
	public Student addStudent(@RequestBody Student student) {
		return studentService.addStudent(student);
	}

	@PutMapping("/{id}")
	public Student updateStudent(@PathVariable String id, @RequestBody Student student) {
		return studentService.updateStudent(id, student);
	}

	@DeleteMapping("/{id}")
	public void deleteStudent(@PathVariable String id) {
		studentService.deleteStudent(id);
	}

	@GetMapping("/age/less-than")
	public ResponseEntity<List<Student>> findStudentsByAgeLessThan(@RequestParam int age) {
		return new ResponseEntity<>(studentService.findStudentsByAgeLessThan(age), HttpStatus.OK);
	}
	
	@GetMapping("/age/between")
    public ResponseEntity<List<Student>> findStudentsByAgeBetween(@RequestParam int startAge, @RequestParam int endAge) {
        return new ResponseEntity<>(studentService.findStudentsByAgeBetween(startAge, endAge), HttpStatus.OK);
    }

    @GetMapping("/parents/father-names")
    public ResponseEntity<List<String>> findFatherNamesByStudentAgeLessThan(@RequestParam int age) {
        List<ParentDetails> parentDetails = studentService.findParentDetailsByStudentAgeLessThan(age);
        List<String> fatherNames = parentDetails.stream()
                                                .map(ParentDetails::getFatherName)
                                                .collect(Collectors.toList());
        return new ResponseEntity<>(fatherNames, HttpStatus.OK);
    }
}
