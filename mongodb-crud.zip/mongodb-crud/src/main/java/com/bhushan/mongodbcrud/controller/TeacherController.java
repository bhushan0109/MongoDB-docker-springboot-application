package com.bhushan.mongodbcrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bhushan.mongodbcrud.entity.Course;
import com.bhushan.mongodbcrud.entity.Teacher;
import com.bhushan.mongodbcrud.service.TeacherService;

@RestController
@RequestMapping("/api/teachers")
public class TeacherController {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	
	@Autowired
	private TeacherService teacherService;

	// Create
	@PostMapping
	public ResponseEntity<Teacher> createTeacher(@RequestBody Teacher teacher) {
		Teacher savedTeacher = mongoTemplate.save(teacher);
		return new ResponseEntity<>(savedTeacher, HttpStatus.CREATED);
	}

	// Read
	@GetMapping("/{id}")
	public ResponseEntity<Teacher> getTeacherById(@PathVariable String id) {
		Teacher teacher = mongoTemplate.findById(id, Teacher.class);
		if (teacher != null) {
			return new ResponseEntity<>(teacher, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Update
	@PutMapping("/{id}")
	public ResponseEntity<Teacher> updateTeacher(@PathVariable String id, @RequestBody Teacher teacherDetails) {
		Teacher teacher = mongoTemplate.findById(id, Teacher.class);
		if (teacher != null) {
			teacher.setName(teacherDetails.getName());
			teacher.setCourses(teacherDetails.getCourses());
			Teacher updatedTeacher = mongoTemplate.save(teacher);
			return new ResponseEntity<>(updatedTeacher, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Delete
	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteTeacher(@PathVariable String id) {
		Teacher teacher = mongoTemplate.findById(id, Teacher.class);
		if (teacher != null) {
			mongoTemplate.remove(teacher);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// List all
	@GetMapping
	public ResponseEntity<List<Teacher>> getAllTeachers() {
		List<Teacher> teachers = mongoTemplate.findAll(Teacher.class);
		return new ResponseEntity<>(teachers, HttpStatus.OK);
	}

	 @GetMapping("/by-course")
	    public ResponseEntity<List<Teacher>> findTeachersByCourseName(@RequestParam String courseName) {
		   Query query = new Query();
	        query.addCriteria(Criteria.where("courses.name").is(courseName));
	       List<Teacher> list = mongoTemplate.find(query, Teacher.class);
	        if (!list.isEmpty()) {
	            return new ResponseEntity<>(list, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

}
