package com.bhushan.mongodbcrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.bhushan.mongodbcrud.entity.Course;

@Service
public class CourseService {

	@Autowired
	private MongoTemplate mongoTemplate;

	public List<Course> getAllCourses() {
		return mongoTemplate.findAll(Course.class);
	}

	public Course getCourseById(String id) {
		return mongoTemplate.findById(id, Course.class);
	}

	public Course addCourse(Course course) {
		return mongoTemplate.save(course);
	}

	public Course updateCourse(String id, Course course) {
		course.setId(id);
		return mongoTemplate.save(course);
	}

	public void deleteCourse(String id) {
		mongoTemplate.remove(mongoTemplate.findById(id, Course.class));
	}
}
