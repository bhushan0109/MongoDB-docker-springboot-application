package com.bhushan.mongodbcrud.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ParentDetails {
    private String fatherName;
    private String motherName;
    private String contactNumber;

    // Getters and Setters
}
