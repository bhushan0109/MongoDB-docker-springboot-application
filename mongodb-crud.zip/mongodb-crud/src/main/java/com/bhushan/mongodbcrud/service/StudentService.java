package com.bhushan.mongodbcrud.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.bhushan.mongodbcrud.entity.ParentDetails;
import com.bhushan.mongodbcrud.entity.Student;

@Service
public class StudentService {

    @Autowired
    private MongoTemplate mongoTemplate;

    public List<Student> getAllStudents() {
        return mongoTemplate.findAll(Student.class);
    }

    public Student getStudentById(String id) {
        return mongoTemplate.findById(id, Student.class);
    }

    public Student addStudent(Student student) {
        return mongoTemplate.save(student);
    }

    public Student updateStudent(String id, Student student) {
        student.setId(id);
        return mongoTemplate.save(student);
    }

    public void deleteStudent(String id) {
        mongoTemplate.remove(mongoTemplate.findById(id, Student.class));
    }
    
    public List<Student> findStudentsByAgeLessThan(int age) {
        Query query = new Query();
        query.addCriteria(Criteria.where("age").lt(age));
        return mongoTemplate.find(query, Student.class);
    }
    
    public List<Student> findStudentsByAgeBetween(int startAge, int endAge) {
        Query query = new Query();
        query.addCriteria(Criteria.where("age").gte(startAge).lte(endAge));
        return mongoTemplate.find(query, Student.class);
    }
    
    public List<ParentDetails> findParentDetailsByStudentAgeLessThan(int age) {
        Query query = new Query();
        query.addCriteria(Criteria.where("age").lt(age));
        query.fields().include("parentDetails.fatherName");
        List<Student> students = mongoTemplate.find(query, Student.class);
        return students.stream()
                       .flatMap(student -> student.getParentDetails().stream())
                       .collect(Collectors.toList());
    }
}
