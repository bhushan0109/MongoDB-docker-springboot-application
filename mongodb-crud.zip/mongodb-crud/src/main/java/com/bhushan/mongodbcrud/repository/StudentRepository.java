package com.bhushan.mongodbcrud.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.bhushan.mongodbcrud.entity.Student;

public interface StudentRepository extends MongoRepository<Student, String> {

//	  @Query(value = "{ 'age': { '$lt': 15 } }", fields = "{ 'parentDetails.fatherName': 1, '_id': 0 }")
//	    List<Student> findStudentsByAgeLessThan15();

	@Query(value = "{ 'age': { '$lt': ?0 } }", fields = "{ 'parentDetails.fatherName': 1, '_id': 0 }")
	List<Student> findStudentsByAgeLessThan(int age);

}
