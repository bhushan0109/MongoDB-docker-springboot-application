package com.bhushan.mongodbcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
